Front Teeth should be immediately pulled from build plate and be shaped to the brin of hat or have heat applied to the underside with a lighter/torch and then bent.
they're printing in a flat orintation to avoid supports.

Full product is printed in PETG with 3 walls and 10% infill